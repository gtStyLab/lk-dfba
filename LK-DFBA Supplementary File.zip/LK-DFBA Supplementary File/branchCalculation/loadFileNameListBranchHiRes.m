

fileNameList = {
'branch_k-01_hiRes.mat';
'branch_k-02_hiRes.mat';
'branch_k-03_hiRes.mat';
'branch_k-04_hiRes.mat';
'branch_k-05_hiRes.mat';
'branch_k-06_hiRes.mat';
'branch_k-07_hiRes.mat';
'branch_k-08_hiRes.mat';
'branch_k-09_hiRes.mat';
'branch_k-10_hiRes.mat';
};
