fclose('all'); close; clear; clc;



